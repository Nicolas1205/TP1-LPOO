Usuarios en la base de datos (contraseña es la misma que el usuario): anachuri, secadora, nicolas
